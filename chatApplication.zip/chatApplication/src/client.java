import java.io.*;

import java.net.*;
public class client {
    // character stream
    BufferedReader br;
    PrintWriter out1;
    Socket socket1;
    public client() {
        try {
            socket1 = new Socket("localhost", 4444);
            System.out.println("connection established .. ");
            System.out.println("waiting for message ..");

           // this is character stream reader ...

            InputStreamReader fs    = new InputStreamReader(socket1.getInputStream());

            br = new BufferedReader(fs);

            out1 = new PrintWriter(socket1.getOutputStream());

            startreading();
            startwriting();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public void startreading(){
        Runnable r1 = ()-> {
            System.out.println("");
            while(true){
                try{
                    String msg  = br.readLine();
                    if(msg.equals("exit")){
                        System.out.println("server has stopped ...");
                        break ;
                    }

                    System.err.println("                                                                    : "+ msg);
                }catch(Exception e){
                    System.out.println("connnection closed ");

                }
            }
        };new Thread(r1).start();
    }
    public void startwriting(){
        Runnable r2 = () -> {
            System.out.println("");
            try {
                while(!socket1.isClosed()){
                    BufferedReader br1 = new BufferedReader(new InputStreamReader(System.in));
                    String  content = br1.readLine();
                    out1.println(content);
                    out1.flush();
                }
            } catch (Exception e) {
                System.out.println("connnection closed ");
            }
        };new Thread(r2).start();
    }


    public static void main(String[] args) {


            new client();
        }
        }

